/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  ShoppingCart, 
  User, 
  ShieldCheck, 
  LogOut, 
  Plus, 
  Edit, 
  Trash2, 
  History, 
  Trophy, 
  Camera,
  ChevronRight,
  Package,
  DollarSign,
  Users,
  CheckCircle,
  Clock,
  Copy,
  QrCode,
  Download
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---
interface UserInfo {
  id: string;
  nome: string;
  email: string;
  role: 'admin' | 'user';
  totalGasto: number;
  fotoPerfil: string | null;
}

interface Product {
  id: string;
  nome: string;
  descricao: string;
  preco: number;
  imagem: string;
  tipo: 'mapa' | 'passe' | 'outro';
  conteudo: string;
}

interface Purchase {
  id: string;
  usuarioId: string;
  produtoId: string;
  valor: number;
  status: 'pending' | 'approved';
  data: string;
}

// --- Constants ---
const RANKS = [
  { name: 'Bronze', min: 0, max: 29, color: 'text-orange-600', bg: 'bg-orange-600/20' },
  { name: 'Prata', min: 30, max: 59, color: 'text-gray-400', bg: 'bg-gray-400/20' },
  { name: 'Ouro', min: 60, max: 99, color: 'text-yellow-500', bg: 'bg-yellow-500/20' },
  { name: 'Diamante', min: 100, max: 199, color: 'text-blue-400', bg: 'bg-blue-400/20' },
  { name: 'Mestre', min: 200, max: Infinity, color: 'text-purple-500', bg: 'bg-purple-500/20' }
];

const PixModal = ({ pixData, onClose, onPaymentApproved }: { pixData: any, onClose: () => void, onPaymentApproved: () => void }) => {
  const [copied, setCopied] = useState(false);
  const [status, setStatus] = useState(pixData.status);
  const [checking, setChecking] = useState(false);

  const checkStatus = async () => {
    setChecking(true);
    try {
      const res = await fetch(`/api/pagamento/${pixData.id}`, {
        headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
      });
      const data = await res.json();
      if (data.status === 'approved') {
        setStatus('approved');
        setTimeout(() => {
          onPaymentApproved();
        }, 2000);
      } else {
        const btn = document.getElementById('confirm-btn');
        if (btn) {
          btn.classList.add('shake');
          setTimeout(() => btn.classList.remove('shake'), 500);
        }
      }
    } catch (err) {
      console.error("Error checking payment status", err);
    } finally {
      setChecking(false);
    }
  };

  useEffect(() => {
    const interval = setInterval(async () => {
      if (status === 'approved') return;
      await checkStatus();
    }, 10000);

    return () => clearInterval(interval);
  }, [pixData.id, status]);

  const handleCopy = () => {
    navigator.clipboard.writeText(pixData.qr_code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/95 backdrop-blur-xl z-[200] flex items-center justify-center p-4 sm:p-6"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        className="glass w-full max-w-md rounded-[2.5rem] p-6 sm:p-10 text-center shadow-[0_0_50px_rgba(37,99,235,0.2)]"
      >
        {status === 'approved' ? (
          <div className="py-10">
            <div className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-8">
              <CheckCircle className="text-green-500 w-14 h-14" />
            </div>
            <h3 className="text-3xl font-black italic tracking-tighter text-white mb-3 uppercase">Sucesso Total!</h3>
            <p className="text-gray-400 font-medium">Seu produto foi liberado e já está disponível.</p>
          </div>
        ) : (
          <>
            <div className="flex justify-between items-center mb-8">
              <div className="text-left">
                <h3 className="text-2xl font-black italic tracking-tighter text-white uppercase">Pagamento PIX</h3>
                <p className="text-gray-500 text-[10px] font-bold uppercase tracking-widest mt-1">Aprovação instantânea</p>
              </div>
              <button onClick={onClose} className="p-2 text-gray-500 hover:text-white transition-colors bg-white/5 rounded-full">
                <LogOut size={20} />
              </button>
            </div>

            <div className="bg-white p-5 rounded-[2rem] mb-8 inline-block mx-auto shadow-[0_0_30px_rgba(255,255,255,0.1)]">
              <img 
                src={`data:image/png;base64,${pixData.qr_code_base64}`} 
                className="w-44 h-44 sm:w-52 sm:h-52"
                alt="QR Code PIX"
              />
            </div>

            <div className="space-y-5">
              <div className="bg-black/40 border border-white/5 p-4 rounded-2xl text-left relative group">
                <p className="text-[10px] font-black uppercase tracking-widest text-gray-500 mb-2 ml-1">Código Copia e Cola</p>
                <p className="text-[11px] text-gray-400 break-all line-clamp-2 pr-10 font-mono">{pixData.qr_code}</p>
                <button 
                  onClick={handleCopy}
                  className="absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 flex items-center justify-center bg-blue-600/20 text-blue-400 rounded-xl hover:bg-blue-600 hover:text-white transition-all"
                >
                  {copied ? <CheckCircle size={18} /> : <Copy size={18} />}
                </button>
              </div>

              <div className="flex items-center justify-center gap-3 text-yellow-500 bg-yellow-500/10 py-4 rounded-2xl border border-yellow-500/20">
                <Clock size={20} className="animate-pulse" />
                <span className="text-xs font-black uppercase tracking-[0.15em]">Processando...</span>
              </div>

              <button 
                id="confirm-btn"
                onClick={checkStatus}
                disabled={checking}
                className="btn-primary w-full py-4 text-sm uppercase tracking-widest"
              >
                {checking ? 'Verificando...' : 'Confirmar Pagamento'}
              </button>
            </div>
          </>
        )}
      </motion.div>
    </motion.div>
  );
};

const getRank = (totalGasto: number) => {
  return RANKS.find(r => totalGasto >= r.min && totalGasto <= r.max) || RANKS[0];
};

// --- Components ---

const Navbar = ({ user, onLogout, setPage }: { user: UserInfo | null, onLogout: () => void, setPage: (p: string) => void }) => (
  <nav className="glass-dark sticky top-0 z-50 px-4 sm:px-8 py-3 sm:py-4 flex justify-between items-center">
    <div className="flex items-center gap-2 cursor-pointer" onClick={() => setPage('store')}>
      <div className="w-9 h-9 sm:w-10 sm:h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center shadow-[0_0_15px_rgba(37,99,235,0.4)]">
        <ShoppingCart className="text-white w-5 h-5 sm:w-6 sm:h-6" />
      </div>
      <span className="text-lg sm:text-xl font-black bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-400 tracking-tighter hidden xs:block">
        GAMER<span className="text-white">STORE</span>
      </span>
    </div>
    
    <div className="flex items-center gap-3 sm:gap-6">
      {user && (
        <>
          <div className="flex items-center gap-1 sm:gap-4">
            <button onClick={() => setPage('store')} className="p-2 text-gray-400 hover:text-blue-400 transition-colors sm:hidden">
              <Package size={20} />
            </button>
            <button onClick={() => setPage('store')} className="text-gray-400 hover:text-blue-400 transition-colors font-bold text-sm hidden sm:block">Loja</button>
            
            <button onClick={() => setPage('profile')} className="p-2 text-gray-400 hover:text-blue-400 transition-colors sm:hidden">
              <User size={20} />
            </button>
            <button onClick={() => setPage('profile')} className="text-gray-400 hover:text-blue-400 transition-colors font-bold text-sm hidden sm:block">Perfil</button>
            
            {user.role === 'admin' && (
              <>
                <button onClick={() => setPage('admin')} className="p-2 text-gray-400 hover:text-purple-400 transition-colors sm:hidden">
                  <ShieldCheck size={20} />
                </button>
                <button onClick={() => setPage('admin')} className="text-gray-400 hover:text-purple-400 transition-colors font-bold text-sm hidden sm:block flex items-center gap-1">
                  <ShieldCheck size={16} /> Admin
                </button>
              </>
            )}
          </div>
          
          <div className="h-6 w-px bg-white/10 mx-1" />
          
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="text-right hidden md:block">
              <p className="text-xs font-black text-white leading-none">{user.nome}</p>
              <p className={`text-[9px] uppercase font-black tracking-widest mt-1 ${getRank(user.totalGasto).color}`}>
                {getRank(user.totalGasto).name}
              </p>
            </div>
            <img 
              src={user.fotoPerfil || `https://ui-avatars.com/api/?name=${user.nome}&background=2563eb&color=fff`} 
              className="w-8 h-8 sm:w-10 sm:h-10 rounded-full border-2 border-blue-500/30 object-cover"
              alt="Avatar"
            />
            <button onClick={onLogout} className="p-2 text-gray-500 hover:text-red-500 transition-colors">
              <LogOut size={18} />
            </button>
          </div>
        </>
      )}
    </div>
  </nav>
);

const RankProgress = ({ totalGasto }: { totalGasto: number }) => {
  const currentRank = getRank(totalGasto);
  const nextRank = RANKS[RANKS.indexOf(currentRank) + 1];
  const progress = nextRank ? ((totalGasto - currentRank.min) / (nextRank.min - currentRank.min)) * 100 : 100;

  return (
    <div className="glass p-6 sm:p-8 rounded-[2.5rem]">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-4 mb-6">
        <div>
          <p className="text-gray-500 text-[10px] uppercase tracking-[0.3em] font-black mb-2 ml-1">Patente Atual</p>
          <h3 className={`text-3xl font-black italic tracking-tighter uppercase ${currentRank.color}`}>{currentRank.name}</h3>
        </div>
        <div className="sm:text-right">
          <p className="text-gray-500 text-[10px] uppercase tracking-[0.3em] font-black mb-2 ml-1">Total Investido</p>
          <h3 className="text-3xl font-black text-white italic tracking-tighter">R$ {totalGasto.toFixed(2)}</h3>
        </div>
      </div>
      
      <div className="relative h-4 bg-white/5 rounded-full overflow-hidden border border-white/5">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${Math.min(progress, 100)}%` }}
          className={`absolute top-0 left-0 h-full bg-gradient-to-r from-blue-600 to-purple-600 shadow-[0_0_20px_rgba(37,99,235,0.4)]`}
        />
      </div>
      
      {nextRank && (
        <p className="text-gray-500 text-[10px] mt-3 text-right uppercase font-black tracking-widest">
          Faltam R$ {(nextRank.min - totalGasto).toFixed(2)} para <span className={nextRank.color}>{nextRank.name}</span>
        </p>
      )}
    </div>
  );
};

export default function App() {
  const [page, setPage] = useState('login');
  const [user, setUser] = useState<UserInfo | null>(null);
  const [token, setToken] = useState<string | null>(localStorage.getItem('token'));
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pixData, setPixData] = useState<any>(null);

  // Auth check
  useEffect(() => {
    if (token) {
      fetchProfile();
    } else {
      setPage('login');
    }
  }, [token]);

  const fetchProfile = async () => {
    try {
      const res = await fetch('/api/perfil', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await res.json();
        setUser(data);
        setPage('store');
        fetchProducts();
      } else {
        handleLogout();
      }
    } catch (err) {
      handleLogout();
    }
  };

  const fetchProducts = async () => {
    try {
      const res = await fetch('/api/produtos', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      setProducts(data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setUser(null);
    setPage('login');
  };

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const formData = new FormData(e.currentTarget);
    const email = formData.get('email');
    const senha = formData.get('senha');

    try {
      const res = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, senha })
      });
      const data = await res.json();
      if (res.ok) {
        localStorage.setItem('token', data.token);
        setToken(data.token);
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError('Erro ao conectar ao servidor');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    const formData = new FormData(e.currentTarget);
    const nome = formData.get('nome');
    const email = formData.get('email');
    const senha = formData.get('senha');

    try {
      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nome, email, senha })
      });
      const data = await res.json();
      if (res.ok) {
        setPage('login');
        alert('Conta criada com sucesso! Faça login.');
      } else {
        setError(data.error);
      }
    } catch (err: any) {
      console.error("Register fetch error:", err);
      setError(`Erro ao conectar ao servidor: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const handleBuy = async (produtoId: string, extraData?: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/criar-pix', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ produtoId, extraData })
      });
      const data = await res.json();
      if (res.ok) {
        setPixData(data);
      } else {
        alert(data.error);
      }
    } catch (err) {
      alert('Erro ao processar compra');
    } finally {
      setLoading(false);
    }
  };

  // --- Pages ---

  const LoginPage = () => (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center p-4 sm:p-6 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-900/20 via-black to-black">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md glass p-6 sm:p-10 rounded-[2.5rem] shadow-[0_0_50px_rgba(37,99,235,0.1)]"
      >
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-purple-600 rounded-3xl mx-auto flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(37,99,235,0.4)]">
            <ShoppingCart className="text-white w-8 h-8" />
          </div>
          <h1 className="text-3xl font-black text-white tracking-tighter italic uppercase">Acesso Gamer</h1>
          <p className="text-gray-500 text-sm mt-2 font-medium">Entre para continuar suas compras</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-5">
          <div>
            <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-2 ml-1">Email de Acesso</label>
            <input 
              name="email" 
              type="email" 
              required 
              className="input-field" 
              placeholder="seu@email.com"
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-2 ml-1">Senha Secreta</label>
            <input 
              name="senha" 
              type="password" 
              required 
              className="input-field" 
              placeholder="••••••••"
            />
          </div>
          {error && (
            <motion.p 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-red-500 text-xs font-bold bg-red-500/10 p-3 rounded-xl border border-red-500/20"
            >
              {error}
            </motion.p>
          )}
          <button 
            disabled={loading}
            className="btn-primary w-full py-4 text-sm uppercase tracking-widest"
          >
            {loading ? 'Autenticando...' : 'Entrar na Loja'}
          </button>
        </form>
        
        <p className="text-center text-gray-500 text-sm mt-8 font-medium">
          Novo por aqui? <button onClick={() => setPage('register')} className="text-blue-400 font-bold hover:text-blue-300 transition-colors">Crie sua conta</button>
        </p>
      </motion.div>
    </div>
  );

  const RegisterPage = () => (
    <div className="min-h-screen bg-[#050505] flex items-center justify-center p-4 sm:p-6 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-purple-900/20 via-black to-black">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-md glass p-6 sm:p-10 rounded-[2.5rem] shadow-[0_0_50px_rgba(147,51,234,0.1)]"
      >
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-blue-600 rounded-3xl mx-auto flex items-center justify-center mb-6 shadow-[0_0_30px_rgba(147,51,234,0.4)]">
            <User className="text-white w-8 h-8" />
          </div>
          <h1 className="text-3xl font-black text-white tracking-tighter italic uppercase">Nova Conta</h1>
          <p className="text-gray-500 text-sm mt-2 font-medium">Junte-se à elite dos gamers</p>
        </div>

        <form onSubmit={handleRegister} className="space-y-5">
          <div>
            <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-2 ml-1">Nome de Usuário</label>
            <input 
              name="nome" 
              type="text" 
              required 
              className="input-field" 
              placeholder="Como quer ser chamado?"
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-2 ml-1">Seu Melhor Email</label>
            <input 
              name="email" 
              type="email" 
              required 
              className="input-field" 
              placeholder="seu@email.com"
            />
          </div>
          <div>
            <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-2 ml-1">Senha de Acesso</label>
            <input 
              name="senha" 
              type="password" 
              required 
              className="input-field" 
              placeholder="••••••••"
            />
          </div>
          {error && (
            <motion.p 
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              className="text-red-500 text-xs font-bold bg-red-500/10 p-3 rounded-xl border border-red-500/20"
            >
              {error}
            </motion.p>
          )}
          <button 
            disabled={loading}
            className="btn-primary w-full py-4 text-sm uppercase tracking-widest bg-purple-600 hover:bg-purple-500 hover:shadow-[0_0_20px_rgba(147,51,234,0.4)]"
          >
            {loading ? 'Criando...' : 'Finalizar Cadastro'}
          </button>
        </form>
        
        <p className="text-center text-gray-500 text-sm mt-8 font-medium">
          Já é de casa? <button onClick={() => setPage('login')} className="text-purple-400 font-bold hover:text-purple-300 transition-colors">Fazer Login</button>
        </p>
      </motion.div>
    </div>
  );

  const StorePage = () => {
    const [playerIds, setPlayerIds] = useState<Record<string, string>>({});

    return (
      <div className="min-h-screen bg-[#050505] text-white pb-20">
        <Navbar user={user} onLogout={handleLogout} setPage={setPage} />
        
        <header className="relative h-[300px] sm:h-[450px] flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-blue-900/20 via-black/60 to-[#050505] z-10" />
          <img 
            src="https://picsum.photos/seed/gamer/1920/1080" 
            className="absolute inset-0 w-full h-full object-cover opacity-30 scale-105 blur-[2px]"
            alt="Banner"
          />
          <div className="relative z-20 text-center px-6 max-w-4xl">
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="inline-block px-4 py-1 rounded-full glass-dark mb-6 border-blue-500/20"
            >
              <span className="text-[10px] font-black uppercase tracking-[0.3em] text-blue-400">Loja Oficial Gamer</span>
            </motion.div>
            <motion.h2 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-4xl sm:text-7xl font-black italic tracking-tighter mb-6 uppercase leading-[0.9] drop-shadow-[0_0_30px_rgba(37,99,235,0.3)]"
            >
              Equipe-se com <br /> <span className="text-blue-500">o melhor</span>
            </motion.h2>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-gray-400 text-sm sm:text-lg max-w-2xl mx-auto font-medium leading-relaxed"
            >
              Os melhores itens digitais, passes e serviços exclusivos para elevar seu nível de jogo ao patamar profissional.
            </motion.p>
          </div>
        </header>

        <main className="max-w-7xl mx-auto px-4 sm:px-8 -mt-12 sm:-mt-20 relative z-30">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-10">
            {products.map((product, idx) => {
              const needsId = product.nome.toLowerCase().includes('passe') || product.nome.toLowerCase().includes('fire');
              
              return (
                <motion.div 
                  key={product.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.1 }}
                  className="group glass rounded-[2.5rem] overflow-hidden hover:border-blue-500/40 transition-all hover:shadow-[0_0_40px_rgba(37,99,235,0.1)] flex flex-col"
                >
                  <div className="relative h-56 sm:h-72 overflow-hidden">
                    <img 
                      src={product.imagem} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      alt={product.nome}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    <div className="absolute bottom-4 left-6">
                      <div className="glass-dark px-4 py-2 rounded-2xl border-blue-500/30">
                        <span className="text-blue-400 font-black italic text-lg tracking-tighter">R$ {product.preco.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                  <div className="p-6 sm:p-8 flex-1 flex flex-col">
                    <h3 className="text-2xl font-black italic tracking-tighter mb-2 uppercase group-hover:text-blue-400 transition-colors">{product.nome}</h3>
                    <p className="text-gray-500 text-sm mb-6 line-clamp-2 font-medium leading-relaxed">{product.descricao}</p>
                    
                    <div className="mt-auto space-y-4">
                      {needsId && (
                        <div className="space-y-2">
                          <label className="block text-[10px] font-black uppercase tracking-[0.2em] text-gray-500 ml-1">ID do Jogador</label>
                          <input 
                            type="text" 
                            placeholder="Ex: 123456789"
                            value={playerIds[product.id] || ''}
                            onChange={(e) => setPlayerIds({...playerIds, [product.id]: e.target.value})}
                            className="input-field py-2.5 text-xs"
                          />
                        </div>
                      )}

                      <button 
                        onClick={() => {
                          if (needsId && !playerIds[product.id]) {
                            alert('Por favor, digite seu ID do jogador antes de comprar.');
                            return;
                          }
                          handleBuy(product.id, playerIds[product.id]);
                        }}
                        className="btn-primary w-full py-4 text-xs uppercase tracking-[0.2em] flex items-center justify-center gap-2"
                      >
                        Comprar Agora <ChevronRight size={16} />
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </main>
      </div>
    );
  };

  const ProfilePage = () => {
    const [profile, setProfile] = useState<any>(null);
    const [editing, setEditing] = useState(false);

    useEffect(() => {
      fetchFullProfile();
    }, []);

    const fetchFullProfile = async () => {
      const res = await fetch('/api/perfil', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      setProfile(data);
    };

    const handleUpdateProfile = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const res = await fetch('/api/perfil', {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData
      });
      if (res.ok) {
        setEditing(false);
        fetchFullProfile();
        fetchProfile(); // Update navbar info
      }
    };

    if (!profile) return <div className="min-h-screen bg-[#050505] text-white p-10 flex items-center justify-center font-black italic tracking-widest uppercase animate-pulse">Carregando...</div>;

    return (
      <div className="min-h-screen bg-[#050505] text-white pb-20">
        <Navbar user={user} onLogout={handleLogout} setPage={setPage} />
        
        <main className="max-w-6xl mx-auto px-4 sm:px-8 py-8 sm:py-12">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Sidebar Info */}
            <div className="lg:col-span-4 space-y-6">
              <div className="glass p-8 rounded-[2.5rem] text-center relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-blue-600 to-purple-600" />
                <div className="relative inline-block mb-6">
                  <img 
                    src={profile.fotoPerfil || `https://ui-avatars.com/api/?name=${profile.nome}&background=2563eb&color=fff`} 
                    className="w-32 h-32 rounded-full border-4 border-white/10 object-cover mx-auto shadow-[0_0_30px_rgba(37,99,235,0.2)]"
                    alt="Avatar"
                  />
                  <button 
                    onClick={() => setEditing(true)}
                    className="absolute bottom-0 right-0 bg-blue-600 p-2.5 rounded-full border-4 border-[#050505] hover:bg-blue-500 transition-all shadow-xl"
                  >
                    <Camera size={18} />
                  </button>
                </div>
                <h2 className="text-3xl font-black italic tracking-tighter uppercase mb-1">{profile.nome}</h2>
                <p className="text-gray-500 text-sm mb-6 font-medium tracking-tight">{profile.email}</p>
                <div className={`inline-block px-5 py-1.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] ${getRank(profile.totalGasto).bg} ${getRank(profile.totalGasto).color} border border-current/20`}>
                  Patente {getRank(profile.totalGasto).name}
                </div>
              </div>

              <div className="glass p-8 rounded-[2.5rem]">
                <h4 className="text-[10px] font-black uppercase tracking-[0.3em] text-gray-500 mb-6 flex items-center gap-2 ml-1">
                  <Trophy size={14} className="text-yellow-500" /> Estatísticas
                </h4>
                <div className="space-y-5">
                  <div className="flex justify-between items-center bg-white/5 p-4 rounded-2xl border border-white/5">
                    <span className="text-gray-400 text-xs font-bold uppercase tracking-widest">Total Gasto</span>
                    <span className="font-black italic text-blue-400">R$ {profile.totalGasto.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center bg-white/5 p-4 rounded-2xl border border-white/5">
                    <span className="text-gray-400 text-xs font-bold uppercase tracking-widest">Compras</span>
                    <span className="font-black italic text-white">{profile.compras?.length || 0}</span>
                  </div>
                  <div className="flex justify-between items-center bg-white/5 p-4 rounded-2xl border border-white/5">
                    <span className="text-gray-400 text-xs font-bold uppercase tracking-widest">Membro</span>
                    <span className="font-black italic text-white text-[11px]">{new Date(profile.dataCriacao).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-8 space-y-8">
              <div className="glass p-8 rounded-[2.5rem]">
                <RankProgress totalGasto={profile.totalGasto} />
              </div>

              <div className="glass rounded-[2.5rem] overflow-hidden">
                <div className="p-8 border-b border-white/10 flex justify-between items-center">
                  <h3 className="text-xl font-black italic tracking-tighter flex items-center gap-3 uppercase">
                    <History size={22} className="text-blue-500" /> Histórico
                  </h3>
                </div>
                <div className="divide-y divide-white/5">
                  {profile.compras?.length > 0 ? (
                    profile.compras.map((compra: any) => {
                      const product = products.find(p => p.id === compra.produtoId);
                      return (
                        <div key={compra.id} className="p-6 sm:p-8 hover:bg-white/5 transition-colors group">
                          <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center gap-5">
                              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center ${compra.status === 'approved' ? 'bg-green-500/10 text-green-500 border border-green-500/20' : 'bg-yellow-500/10 text-yellow-500 border border-yellow-500/20'}`}>
                                {compra.status === 'approved' ? <CheckCircle size={28} /> : <Clock size={28} />}
                              </div>
                              <div>
                                <p className="font-black italic text-white uppercase tracking-tight">Pedido #{compra.id.slice(0, 8)}</p>
                                <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-1">{new Date(compra.data).toLocaleString()}</p>
                              </div>
                            </div>
                            <div className="text-right">
                              <p className="font-black italic text-blue-400 text-lg tracking-tighter">R$ {compra.valor.toFixed(2)}</p>
                              <p className={`text-[9px] font-black uppercase tracking-[0.2em] mt-1 ${compra.status === 'approved' ? 'text-green-500' : 'text-yellow-500'}`}>
                                {compra.status === 'approved' ? 'Aprovado' : 'Pendente'}
                              </p>
                            </div>
                          </div>
                          
                          {compra.status === 'approved' && product && (
                            <motion.div 
                              initial={{ opacity: 0, y: 10 }}
                              animate={{ opacity: 1, y: 0 }}
                              className="mt-4 p-4 bg-blue-600/10 border border-blue-500/20 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4"
                            >
                              <div className="flex items-center gap-3">
                                <Package size={20} className="text-blue-400" />
                                <div>
                                  <p className="text-[10px] font-black uppercase tracking-widest text-blue-400">Entrega do Produto</p>
                                  <p className="text-sm font-bold text-white">{product.nome}</p>
                                </div>
                              </div>
                              
                              {product.tipo === 'mapa' && product.conteudo && (
                                <a 
                                  href={product.conteudo} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="w-full sm:w-auto bg-blue-600 text-white text-[10px] font-black px-6 py-3 rounded-xl hover:bg-blue-500 transition-all text-center uppercase tracking-widest"
                                >
                                  Baixar Mapa
                                </a>
                              )}
                              
                              {product.tipo === 'passe' && (
                                <div className="w-full sm:w-auto bg-green-600/20 text-green-500 text-[10px] font-black px-6 py-3 rounded-xl border border-green-500/30 text-center uppercase tracking-widest">
                                  Seu pedido já foi entregue
                                </div>
                              )}

                              {product.tipo === 'outro' && product.conteudo && (
                                <div className="text-xs text-gray-400 font-medium italic">
                                  {product.conteudo}
                                </div>
                              )}
                            </motion.div>
                          )}
                        </div>
                      );
                    })
                  ) : (
                    <div className="p-20 text-center text-gray-500 font-bold uppercase tracking-widest text-sm">
                      Nenhuma compra realizada.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>

        <AnimatePresence>
          {editing && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/95 backdrop-blur-xl z-[100] flex items-center justify-center p-4 sm:p-6"
            >
              <motion.div 
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                className="glass w-full max-w-md rounded-[2.5rem] p-8 sm:p-10 shadow-[0_0_50px_rgba(37,99,235,0.2)]"
              >
                <h3 className="text-2xl font-black italic tracking-tighter mb-8 uppercase">Editar Perfil</h3>
                <form onSubmit={handleUpdateProfile} className="space-y-5">
                  <div>
                    <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-2 ml-1">Foto de Perfil</label>
                    <input name="foto" type="file" accept="image/*" className="w-full text-xs text-gray-400 file:mr-4 file:py-2.5 file:px-6 file:rounded-full file:border-0 file:text-[10px] file:font-black file:bg-blue-600 file:text-white hover:file:bg-blue-500 transition-all cursor-pointer" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-2 ml-1">Seu Nome</label>
                    <input name="nome" type="text" defaultValue={profile.nome} className="input-field" />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] mb-2 ml-1">Nova Senha</label>
                    <input name="senha" type="password" className="input-field" placeholder="Deixe em branco para manter" />
                  </div>
                  <div className="flex gap-4 mt-10">
                    <button type="button" onClick={() => setEditing(false)} className="flex-1 bg-white/5 text-gray-400 font-black py-4 rounded-2xl text-xs uppercase tracking-widest hover:bg-white/10 transition-all">Cancelar</button>
                    <button type="submit" className="flex-1 btn-primary text-xs uppercase tracking-widest">Salvar</button>
                  </div>
                </form>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  const AdminPage = () => {
    const [stats, setStats] = useState<any>(null);
    const [showAddModal, setShowAddModal] = useState(false);
    const [editingProduct, setEditingProduct] = useState<Product | null>(null);

    useEffect(() => {
      fetchStats();
    }, []);

    const fetchStats = async () => {
      const res = await fetch('/api/admin/stats', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await res.json();
      setStats(data);
    };

    const handleAddProduct = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);
      const res = await fetch('/api/produtos', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData
      });
      if (res.ok) {
        setShowAddModal(false);
        fetchProducts();
        fetchStats();
      }
    };

    const handleEditProduct = async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      if (!editingProduct) return;
      const formData = new FormData(e.currentTarget);
      const res = await fetch(`/api/produtos/${editingProduct.id}`, {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${token}` },
        body: formData
      });
      if (res.ok) {
        setEditingProduct(null);
        fetchProducts();
        fetchStats();
      }
    };

    const handleDeleteProduct = async (id: string) => {
      if (!confirm('Tem certeza que deseja excluir este produto?')) return;
      try {
        const res = await fetch(`/api/produtos/${id}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          fetchProducts();
          fetchStats();
        } else {
          const data = await res.json();
          alert(`Erro ao excluir: ${data.error || 'Erro desconhecido'}`);
        }
      } catch (err) {
        console.error(err);
        alert('Erro de conexão ao excluir produto');
      }
    };

    const handleApprovePurchase = async (id: string) => {
      if (!confirm('Deseja aprovar este pagamento manualmente? O produto será liberado para o usuário.')) return;
      const res = await fetch(`/api/admin/aprovar-compra/${id}`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (res.ok) {
        fetchStats();
      } else {
        const data = await res.json();
        alert(data.error);
      }
    };

    if (!stats) return <div className="min-h-screen bg-black text-white p-10">Carregando...</div>;

    return (
      <div className="min-h-screen bg-[#050505] text-white pb-20">
        <Navbar user={user} onLogout={handleLogout} setPage={setPage} />
        
        <main className="max-w-7xl mx-auto px-4 sm:px-8 py-8 sm:py-12">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-end gap-6 mb-12">
            <div>
              <h2 className="text-4xl font-black italic tracking-tighter uppercase">Painel Admin</h2>
              <p className="text-gray-500 text-sm font-medium mt-1">Controle total da sua loja gamer</p>
            </div>
            <div className="flex gap-4 w-full sm:w-auto">
              <button 
                onClick={async () => {
                  const res = await fetch('/api/admin/backup', {
                    headers: { 'Authorization': `Bearer ${token}` }
                  });
                  if (res.ok) {
                    const blob = await res.blob();
                    const url = window.URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = 'database_backup.json';
                    a.click();
                  }
                }}
                className="bg-gray-900/50 text-gray-400 hover:text-blue-400 px-6 py-3 rounded-2xl flex items-center gap-2 border border-gray-800 transition-all text-[10px] font-black uppercase tracking-widest"
              >
                <Download size={18} /> Backup
              </button>
              <button 
                onClick={() => setShowAddModal(true)}
                className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-2xl flex items-center gap-2 transition-all text-[10px] font-black uppercase tracking-widest shadow-lg shadow-blue-900/20"
              >
                <Plus size={18} /> Novo Produto
              </button>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 xs:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            {[
              { label: 'Aprovadas', val: stats.approvedSales.length, icon: CheckCircle, color: 'text-green-500', bg: 'bg-green-500/10', border: 'border-green-500/20' },
              { label: 'Pendentes', val: stats.pendingSales.length, icon: Clock, color: 'text-yellow-500', bg: 'bg-yellow-500/10', border: 'border-yellow-500/20' },
              { label: 'Receita', val: `R$ ${stats.totalVendas.toFixed(2)}`, icon: DollarSign, color: 'text-blue-400', bg: 'bg-blue-400/10', border: 'border-blue-400/20' },
              { label: 'Usuários', val: stats.totalUsuarios, icon: Users, color: 'text-purple-500', bg: 'bg-purple-500/10', border: 'border-purple-500/20' }
            ].map((s, i) => (
              <div key={i} className={`bg-gray-900/50 border ${s.border} p-8 rounded-[2.5rem] relative overflow-hidden group hover:bg-gray-900 transition-all`}>
                <div className={`absolute top-0 right-0 w-24 h-24 ${s.bg} rounded-bl-[4rem] -mr-8 -mt-8 transition-all group-hover:scale-110`} />
                <p className="text-gray-500 text-[10px] font-black uppercase tracking-[0.2em] mb-4">{s.label}</p>
                <div className="flex items-center justify-between relative z-10">
                  <h3 className={`text-3xl font-black italic tracking-tighter ${s.color}`}>{s.val}</h3>
                  <s.icon className={`${s.color} opacity-20`} size={32} />
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Pending Sales Management */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-[2.5rem] overflow-hidden">
              <div className="p-8 border-b border-gray-800 bg-gray-900/80 backdrop-blur-md">
                <h3 className="text-xl font-black italic tracking-tighter flex items-center gap-3 uppercase">
                  <Clock size={22} className="text-yellow-500" /> Vendas Pendentes
                </h3>
              </div>
              <div className="divide-y divide-gray-800">
                {stats.pendingSales.length > 0 ? (
                  stats.pendingSales.map((compra: any) => (
                    <div key={compra.id} className="p-6 flex items-center justify-between hover:bg-white/5 transition-all group">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 rounded-2xl bg-yellow-500/10 flex items-center justify-center text-yellow-500 border border-yellow-500/20 group-hover:scale-110 transition-transform">
                          <Clock size={24} />
                        </div>
                        <div>
                          <p className="font-black italic text-white uppercase tracking-tight text-lg">Pedido #{compra.id.slice(0, 8)}</p>
                          <p className="text-[10px] text-gray-500 font-black uppercase tracking-widest mt-1">
                            {compra.extraData ? `ID: ${compra.extraData}` : 'Sem ID'} • <span className="text-blue-400">R$ {compra.valor.toFixed(2)}</span>
                          </p>
                        </div>
                      </div>
                      <button 
                        onClick={() => handleApprovePurchase(compra.id)}
                        className="bg-green-600 text-white text-[10px] font-black px-6 py-3 rounded-xl hover:bg-green-500 transition-all shadow-lg shadow-green-900/20 uppercase tracking-widest"
                      >
                        Aprovar
                      </button>
                    </div>
                  ))
                ) : (
                  <div className="p-20 text-center text-gray-500 font-bold uppercase tracking-widest text-xs">
                    Nenhuma venda pendente.
                  </div>
                )}
              </div>
            </div>

            {/* Ranking */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-[2.5rem] overflow-hidden">
              <div className="p-8 border-b border-gray-800 bg-gray-900/80 backdrop-blur-md">
                <h3 className="text-xl font-black italic tracking-tighter flex items-center gap-3 uppercase">
                  <Trophy size={22} className="text-yellow-500" /> Ranking de Gastos
                </h3>
              </div>
              <div className="divide-y divide-gray-800">
                {stats.ranking.map((u: any, idx: number) => (
                  <div key={u.id} className="p-6 flex items-center justify-between hover:bg-white/5 transition-all group">
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black italic text-sm ${idx === 0 ? 'bg-yellow-500 text-black shadow-lg shadow-yellow-500/20' : 'bg-gray-800 text-gray-400'}`}>
                        {idx + 1}
                      </div>
                      <img 
                        src={u.fotoPerfil || `https://ui-avatars.com/api/?name=${u.nome}&background=2563eb&color=fff`} 
                        className="w-12 h-12 rounded-2xl object-cover border border-gray-700 shadow-xl group-hover:scale-110 transition-transform" 
                        alt="" 
                      />
                      <div>
                        <p className="font-bold text-white text-lg tracking-tight">{u.nome}</p>
                        <p className={`text-[10px] font-black uppercase tracking-widest ${getRank(u.totalGasto).color}`}>
                          {getRank(u.totalGasto).name}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-black italic text-white text-xl tracking-tighter">R$ {u.totalGasto.toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-8">
            {/* Products Management */}
            <div className="bg-gray-900/50 border border-gray-800 rounded-3xl overflow-hidden">
              <div className="p-6 border-b border-gray-800 flex items-center justify-between">
                <h3 className="text-xl font-black italic tracking-tighter flex items-center gap-2">
                  <Package size={20} className="text-blue-500" /> GERENCIAR PRODUTOS
                </h3>
                <button 
                  onClick={() => setShowAddModal(true)}
                  className="bg-blue-600 hover:bg-blue-500 text-white text-[10px] font-black px-4 py-2 rounded-xl transition-all shadow-lg shadow-blue-900/20 uppercase tracking-widest flex items-center gap-2"
                >
                  <Plus size={14} /> NOVO PRODUTO
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 divide-y md:divide-y-0 divide-gray-800">
                {products.map(product => (
                  <div key={product.id} className="p-6 flex items-center justify-between hover:bg-white/5 transition-colors border-b border-gray-800 last:border-b-0">
                    <div className="flex items-center gap-4">
                      <div className="relative">
                        <img src={product.imagem} className="w-16 h-16 rounded-xl object-cover border border-gray-700" alt="" />
                        <div className="absolute -top-1 -right-1 bg-blue-600 text-[8px] font-black px-1.5 py-0.5 rounded-md uppercase">
                          {product.tipo}
                        </div>
                      </div>
                      <div>
                        <p className="font-bold text-white">{product.nome}</p>
                        <p className="text-xs text-blue-400 font-black italic">R$ {product.preco.toFixed(2)}</p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => setEditingProduct(product)}
                        className="p-2 bg-gray-800 text-gray-400 hover:text-blue-400 rounded-lg transition-colors"
                      >
                        <Edit size={18} />
                      </button>
                      <button 
                        onClick={() => handleDeleteProduct(product.id)}
                        className="p-2 bg-gray-800 text-gray-400 hover:text-red-500 rounded-lg transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </main>

        {/* Modals */}
        <AnimatePresence>
          {(showAddModal || editingProduct) && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/90 backdrop-blur-md z-[100] flex items-center justify-center p-6"
            >
              <motion.div 
                initial={{ scale: 0.9, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                className="bg-gray-900 border border-gray-800 w-full max-w-md rounded-3xl p-8 shadow-[0_0_50px_rgba(37,99,235,0.2)]"
              >
                <h3 className="text-2xl font-black italic tracking-tighter mb-6">
                  {editingProduct ? 'EDITAR PRODUTO' : 'ADICIONAR PRODUTO'}
                </h3>
                <form onSubmit={editingProduct ? handleEditProduct : handleAddProduct} className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Imagem do Produto</label>
                    <input name="imagem" type="file" accept="image/*" className="w-full text-sm text-gray-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-black file:bg-blue-600 file:text-white hover:file:bg-blue-500" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Nome</label>
                    <input name="nome" type="text" defaultValue={editingProduct?.nome} required className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500" />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Preço (R$)</label>
                      <input name="preco" type="number" step="0.01" defaultValue={editingProduct?.preco} required className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500" />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Tipo</label>
                      <select name="tipo" defaultValue={editingProduct?.tipo || 'outro'} className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500">
                        <option value="outro">Outro</option>
                        <option value="mapa">Mapa (Link)</option>
                        <option value="passe">Passe (Mensagem)</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Conteúdo de Entrega (Link ou Msg)</label>
                    <input name="conteudo" type="text" defaultValue={editingProduct?.conteudo} className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500" placeholder="Link do mapa ou msg do passe" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Descrição</label>
                    <textarea name="descricao" defaultValue={editingProduct?.descricao} required className="w-full bg-black border border-gray-800 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-blue-500 h-24" />
                  </div>
                  <div className="flex gap-4 mt-8">
                    <button type="button" onClick={() => { setShowAddModal(false); setEditingProduct(null); }} className="flex-1 bg-gray-800 text-white font-black py-3 rounded-xl">CANCELAR</button>
                    <button type="submit" className="flex-1 bg-blue-600 text-white font-black py-3 rounded-xl shadow-[0_0_20px_rgba(37,99,235,0.3)]">SALVAR</button>
                  </div>
                </form>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    );
  };

  return (
    <div className="bg-black min-h-screen selection:bg-blue-500 selection:text-white">
      {page === 'login' && <LoginPage />}
      {page === 'register' && <RegisterPage />}
      {page === 'store' && <StorePage />}
      {page === 'profile' && <ProfilePage />}
      {page === 'admin' && <AdminPage />}

      <AnimatePresence>
        {pixData && (
          <PixModal 
            pixData={pixData} 
            onClose={() => setPixData(null)} 
            onPaymentApproved={() => {
              setPixData(null);
              setPage('profile');
              fetchProfile();
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}
