import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import fs from "fs/promises";
import { fileURLToPath } from "url";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import multer from "multer";
import axios from "axios";
import dotenv from "dotenv";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_PATH = path.join(__dirname, "database.json");
const UPLOADS_DIR = path.join(__dirname, "public", "uploads");
const SECRET_KEY = process.env.JWT_SECRET || "gamer-secret-key-2024";

// Ensure uploads directory exists and default user
async function initStorage() {
  try {
    await fs.mkdir(UPLOADS_DIR, { recursive: true });
    
    // Check if default owner exists
    const db = await readDB();
    const ownerEmail = "animesilva805@gmail.com";
    if (!db.usuarios.find((u: any) => u.email === ownerEmail)) {
      const hashedPassword = await bcrypt.hash("majorjpls22", 10);
      db.usuarios.push({
        id: "owner",
        nome: "Owner",
        email: ownerEmail,
        senha: hashedPassword,
        role: "admin",
        totalGasto: 0,
        fotoPerfil: null,
        dataCriacao: new Date().toISOString()
      });
      await writeDB(db);
      console.log("Default owner created");
    }
  } catch (err) {
    console.error("Error initializing", err);
  }
}
initStorage();

// Database Helpers
async function readDB() {
  try {
    const data = await fs.readFile(DB_PATH, "utf-8");
    return JSON.parse(data);
  } catch (err: any) {
    if (err.code === 'ENOENT') {
      const initialDB = { usuarios: [], produtos: [], compras: [] };
      await writeDB(initialDB);
      return initialDB;
    }
    console.error("Error reading DB:", err);
    return { usuarios: [], produtos: [], compras: [] };
  }
}

async function writeDB(data: any) {
  await fs.writeFile(DB_PATH, JSON.stringify(data, null, 2));
}

// Multer Config
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  },
});
const upload = multer({ storage });

const app = express();
app.use(express.json());
app.use("/uploads", express.static(UPLOADS_DIR));

// Auth Middleware
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) return res.status(401).json({ error: "Acesso negado" });

  jwt.verify(token, SECRET_KEY, (err: any, user: any) => {
    if (err) return res.status(403).json({ error: "Token inválido" });
    req.user = user;
    next();
  });
};

const adminOnly = (req: any, res: any, next: any) => {
  if (req.user.role !== "admin") return res.status(403).json({ error: "Acesso restrito a administradores" });
  next();
};

// --- API ROUTES ---

// Auth
app.post("/api/register", async (req, res) => {
  try {
    const { nome, email, senha } = req.body;
    const db = await readDB();

    if (db.usuarios.find((u: any) => u.email === email)) {
      return res.status(400).json({ error: "Email já cadastrado" });
    }

    const hashedPassword = await bcrypt.hash(senha, 10);
    const newUser = {
      id: Date.now().toString(),
      nome,
      email,
      senha: hashedPassword,
      role: db.usuarios.length === 0 ? "admin" : "user", // First user is admin
      totalGasto: 0,
      fotoPerfil: null,
      dataCriacao: new Date().toISOString()
    };

    db.usuarios.push(newUser);
    await writeDB(db);

    res.status(201).json({ message: "Usuário criado com sucesso" });
  } catch (err) {
    console.error("Register error:", err);
    res.status(500).json({ error: "Erro interno no servidor ao registrar" });
  }
});

app.post("/api/login", async (req, res) => {
  try {
    const { email, senha } = req.body;
    const db = await readDB();
    const user = db.usuarios.find((u: any) => u.email === email);

    if (!user || !(await bcrypt.compare(senha, user.senha))) {
      return res.status(401).json({ error: "Credenciais inválidas" });
    }

    const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, SECRET_KEY, { expiresIn: "7d" });
    res.json({ token, user: { id: user.id, nome: user.nome, email: user.email, role: user.role, totalGasto: user.totalGasto, fotoPerfil: user.fotoPerfil } });
  } catch (err) {
    console.error("Login error:", err);
    res.status(500).json({ error: "Erro interno no servidor ao fazer login" });
  }
});

// User Profile
app.get("/api/perfil", authenticateToken, async (req: any, res) => {
  const db = await readDB();
  const user = db.usuarios.find((u: any) => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: "Usuário não encontrado" });
  
  const compras = db.compras.filter((c: any) => c.usuarioId === user.id);
  res.json({ ...user, senha: undefined, compras });
});

app.put("/api/perfil", authenticateToken, upload.single("foto"), async (req: any, res) => {
  const { nome, senha } = req.body;
  const db = await readDB();
  const userIndex = db.usuarios.findIndex((u: any) => u.id === req.user.id);

  if (userIndex === -1) return res.status(404).json({ error: "Usuário não encontrado" });

  if (nome) db.usuarios[userIndex].nome = nome;
  if (senha) db.usuarios[userIndex].senha = await bcrypt.hash(senha, 10);
  if (req.file) db.usuarios[userIndex].fotoPerfil = `/uploads/${req.file.filename}`;

  await writeDB(db);
  res.json(db.usuarios[userIndex]);
});

// Products
app.get("/api/produtos", authenticateToken, async (req, res) => {
  const db = await readDB();
  res.json(db.produtos);
});

app.post("/api/produtos", authenticateToken, adminOnly, upload.single("imagem"), async (req: any, res) => {
  const { nome, descricao, preco, tipo, conteudo } = req.body;
  const db = await readDB();

  const newProduct = {
    id: Date.now().toString(),
    nome,
    descricao,
    preco: parseFloat(preco),
    tipo: tipo || 'outro',
    conteudo: conteudo || '',
    imagem: req.file ? `/uploads/${req.file.filename}` : "https://picsum.photos/seed/default/400/300"
  };

  db.produtos.push(newProduct);
  await writeDB(db);
  res.status(201).json(newProduct);
});

app.put("/api/produtos/:id", authenticateToken, adminOnly, upload.single("imagem"), async (req: any, res) => {
  const { id } = req.params;
  const { nome, descricao, preco, tipo, conteudo } = req.body;
  const db = await readDB();
  const index = db.produtos.findIndex((p: any) => p.id === id);

  if (index === -1) return res.status(404).json({ error: "Produto não encontrado" });

  if (nome) db.produtos[index].nome = nome;
  if (descricao) db.produtos[index].descricao = descricao;
  if (preco) db.produtos[index].preco = parseFloat(preco);
  if (tipo) db.produtos[index].tipo = tipo;
  if (conteudo !== undefined) db.produtos[index].conteudo = conteudo;
  if (req.file) db.produtos[index].imagem = `/uploads/${req.file.filename}`;

  await writeDB(db);
  res.json(db.produtos[index]);
});

app.delete("/api/produtos/:id", authenticateToken, adminOnly, async (req, res) => {
  const { id } = req.params;
  const db = await readDB();
  db.produtos = db.produtos.filter((p: any) => p.id !== id);
  await writeDB(db);
  res.json({ message: "Produto removido" });
});

// Payments (Mercado Pago)
app.post("/api/criar-pix", authenticateToken, async (req: any, res) => {
  const { produtoId, extraData } = req.body;
  const db = await readDB();
  const produto = db.produtos.find((p: any) => p.id === produtoId);
  const user = db.usuarios.find((u: any) => u.id === req.user.id);

  if (!produto || !user) return res.status(404).json({ error: "Produto ou usuário não encontrado" });

  const accessToken = process.env.MP_ACCESS_TOKEN;
  if (!accessToken) {
    return res.status(500).json({ error: "Token do Mercado Pago não configurado" });
  }

  try {
    const response = await axios.post(
      "https://api.mercadopago.com/v1/payments",
      {
        transaction_amount: produto.preco,
        description: `${produto.nome}${extraData ? ` - ID: ${extraData}` : ""}`,
        payment_method_id: "pix",
        payer: {
          email: user.email,
          first_name: user.nome.split(" ")[0],
          last_name: user.nome.split(" ").slice(1).join(" ") || "User"
        },
        notification_url: `${process.env.APP_URL}/api/webhook`
      },
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "X-Idempotency-Key": Date.now().toString()
        }
      }
    );

    const payment = response.data;
    
    db.compras.push({
      id: payment.id.toString(),
      usuarioId: req.user.id,
      produtoId: produto.id,
      valor: produto.preco,
      status: payment.status,
      data: new Date().toISOString(),
      extraData: extraData || null,
      pix: {
        qr_code: payment.point_of_interaction.transaction_data.qr_code,
        qr_code_base64: payment.point_of_interaction.transaction_data.qr_code_base64
      }
    });
    await writeDB(db);

    res.json({ 
      id: payment.id, 
      status: payment.status,
      qr_code: payment.point_of_interaction.transaction_data.qr_code,
      qr_code_base64: payment.point_of_interaction.transaction_data.qr_code_base64
    });
  } catch (error: any) {
    console.error("PIX Error:", error.response?.data || error.message);
    res.status(500).json({ error: "Erro ao criar pagamento PIX" });
  }
});

app.get("/api/pagamento/:id", authenticateToken, async (req: any, res) => {
  const { id } = req.params;
  const db = await readDB();
  const compra = db.compras.find((c: any) => c.id === id && c.usuarioId === req.user.id);

  if (!compra) return res.status(404).json({ error: "Pagamento não encontrado" });

  // If still pending, try to fetch latest status from MP
  if (compra.status === "pending") {
    const accessToken = process.env.MP_ACCESS_TOKEN;
    try {
      const response = await axios.get(`https://api.mercadopago.com/v1/payments/${id}`, {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      
      if (response.data.status === "approved") {
        const compraIndex = db.compras.findIndex((c: any) => c.id === id);
        db.compras[compraIndex].status = "approved";
        
        // Update user total spent
        const userIndex = db.usuarios.findIndex((u: any) => u.id === compra.usuarioId);
        if (userIndex !== -1) {
          db.usuarios[userIndex].totalGasto += compra.valor;
        }
        await writeDB(db);
        return res.json({ ...compra, status: "approved" });
      }
    } catch (err) {
      console.error("Error checking payment status", err);
    }
  }

  res.json(compra);
});

app.post("/api/criar-pagamento", authenticateToken, async (req: any, res) => {
  const { produtoId } = req.body;
  const db = await readDB();
  const produto = db.produtos.find((p: any) => p.id === produtoId);

  if (!produto) return res.status(404).json({ error: "Produto não encontrado" });

  const accessToken = process.env.MP_ACCESS_TOKEN;
  if (!accessToken) {
    // Fallback for demo if no token
    const mockPreference = {
      id: "mock-" + Date.now(),
      init_point: "#mock-payment"
    };
    
    // Create a pending purchase record
    db.compras.push({
      id: mockPreference.id,
      usuarioId: req.user.id,
      produtoId: produto.id,
      valor: produto.preco,
      status: "pending",
      data: new Date().toISOString()
    });
    await writeDB(db);
    
    return res.json({ preferenceId: mockPreference.id, initPoint: mockPreference.init_point });
  }

  try {
    const response = await axios.post(
      "https://api.mercadopago.com/checkout/preferences",
      {
        items: [
          {
            title: produto.nome,
            unit_price: produto.preco,
            quantity: 1,
            currency_id: "BRL"
          }
        ],
        back_urls: {
          success: `${process.env.APP_URL}/perfil`,
          failure: `${process.env.APP_URL}/`,
          pending: `${process.env.APP_URL}/`
        },
        auto_return: "approved",
        notification_url: `${process.env.APP_URL}/api/webhook`
      },
      {
        headers: {
          Authorization: `Bearer ${accessToken}`
        }
      }
    );

    db.compras.push({
      id: response.data.id,
      usuarioId: req.user.id,
      produtoId: produto.id,
      valor: produto.preco,
      status: "pending",
      data: new Date().toISOString()
    });
    await writeDB(db);

    res.json({ preferenceId: response.data.id, initPoint: response.data.init_point });
  } catch (error: any) {
    console.error("MP Error:", error.response?.data || error.message);
    res.status(500).json({ error: "Erro ao criar preferência de pagamento" });
  }
});

app.post("/api/webhook", async (req, res) => {
  const { type, data, action } = req.body;
  
  // Handle both notification formats
  const resourceId = data?.id || req.query.id;
  const resourceType = type || req.query.topic || action;

  if (resourceType === "payment" || resourceType === "payment.updated") {
    const paymentId = resourceId;
    const accessToken = process.env.MP_ACCESS_TOKEN;
    
    try {
      const response = await axios.get(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      
      const payment = response.data;
      if (payment.status === "approved") {
        const db = await readDB();
        // Try to find by payment ID or preference ID
        const compraIndex = db.compras.findIndex((c: any) => c.id === paymentId.toString() || c.id === payment.preference_id);
        
        if (compraIndex !== -1 && db.compras[compraIndex].status !== "approved") {
          db.compras[compraIndex].status = "approved";
          
          // Update user total spent
          const userId = db.compras[compraIndex].usuarioId;
          const userIndex = db.usuarios.findIndex((u: any) => u.id === userId);
          if (userIndex !== -1) {
            db.usuarios[userIndex].totalGasto += db.compras[compraIndex].valor;
          }
          
          await writeDB(db);
        }
      }
    } catch (error) {
      console.error("Webhook Error:", error);
    }
  }
  
  res.sendStatus(200);
});

// Admin Stats
app.post("/api/admin/aprovar-compra/:id", authenticateToken, adminOnly, async (req, res) => {
  const { id } = req.params;
  const db = await readDB();
  const compraIndex = db.compras.findIndex((c: any) => c.id === id);

  if (compraIndex === -1) return res.status(404).json({ error: "Compra não encontrada" });
  if (db.compras[compraIndex].status === "approved") return res.status(400).json({ error: "Compra já aprovada" });

  db.compras[compraIndex].status = "approved";
  
  // Update user total spent
  const userId = db.compras[compraIndex].usuarioId;
  const userIndex = db.usuarios.findIndex((u: any) => u.id === userId);
  if (userIndex !== -1) {
    db.usuarios[userIndex].totalGasto += db.compras[compraIndex].valor;
  }
  
  await writeDB(db);
  res.json({ message: "Compra aprovada manualmente" });
});

app.get("/api/admin/stats", authenticateToken, adminOnly, async (req, res) => {
  const db = await readDB();
  const approvedSales = db.compras.filter((c: any) => c.status === "approved");
  const pendingSales = db.compras.filter((c: any) => c.status === "pending");
  const ranking = [...db.usuarios].sort((a, b) => b.totalGasto - a.totalGasto);
  
  res.json({
    approvedSales,
    pendingSales,
    ranking,
    totalUsuarios: db.usuarios.length,
    totalVendas: approvedSales.reduce((acc: number, curr: any) => acc + curr.valor, 0)
  });
});

// --- VITE MIDDLEWARE ---
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  const PORT = Number(process.env.PORT) || 3000;
  app.get("/api/admin/backup", authenticateToken, adminOnly, async (req, res) => {
  try {
    const db = await readDB();
    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', 'attachment; filename=database_backup.json');
    res.send(JSON.stringify(db, null, 2));
  } catch (err) {
    res.status(500).json({ error: "Erro ao gerar backup" });
  }
});

app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
